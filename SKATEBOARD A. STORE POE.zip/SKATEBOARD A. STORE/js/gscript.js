
const images = document.querySelectorAll(".gallery img");

const lightbox = document.getElementById("lightbox");
const lightboxImage = document.getElementById("lightboxImage");
const imageCounter = document.getElementById("imageCounter");
const playPauseButton = document.getElementById("playPause");

let currentIndex = 0;
let slideshowInterval = null;

// Open lightbox
function openLightbox(index) {
    currentIndex = index;

    lightbox.classList.add("active");

    showImage();
}

// Display current image
function showImage() {
    lightboxImage.src = images[currentIndex].src;
    lightboxImage.alt = images[currentIndex].alt;

    imageCounter.textContent =
        `${currentIndex + 1} / ${images.length}`;
}

// Change image
function changeSlide(direction) {
    currentIndex += direction;

    if (currentIndex >= images.length) {
        currentIndex = 0;
    }

    if (currentIndex < 0) {
        currentIndex = images.length - 1;
    }

    showImage();
}

// Close lightbox
function closeLightbox() {
    lightbox.classList.remove("active");
    stopSlideshow();
}

// Start slideshow
function startSlideshow() {
    if (slideshowInterval) return;

    slideshowInterval = setInterval(() => {
        changeSlide(1);
    }, 3000);

    playPauseButton.innerHTML = "&#10074;&#10074; Pause";
}

// Stop slideshow
function stopSlideshow() {
    clearInterval(slideshowInterval);
    slideshowInterval = null;

    playPauseButton.innerHTML = "&#9654; Play";
}

// Play / Pause
function toggleSlideshow() {
    if (slideshowInterval) {
        stopSlideshow();
    } else {
        startSlideshow();
    }
}

// Keyboard navigation
document.addEventListener("keydown", function(e) {

    if (!lightbox.classList.contains("active")) return;

    if (e.key === "ArrowRight") {
        changeSlide(1);
    }

    if (e.key === "ArrowLeft") {
        changeSlide(-1);
    }

    if (e.key === "Escape") {
        closeLightbox();
    }

});

// Close when clicking outside image
lightbox.addEventListener("click", function(e) {
    if (e.target === lightbox) {
        closeLightbox();
    }
});

