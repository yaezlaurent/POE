
const form = document.getElementById("contactForm");

form.addEventListener("submit", function (e) {
    e.preventDefault();

    // Get form values
    const fullName = document.getElementById("fullName");
    const email = document.getElementById("email");
    const phone = document.getElementById("phone");
    const subject = document.getElementById("subject");
    const message = document.getElementById("message");

    const successMessage = document.getElementById("successMessage");

    let isValid = true;

    // Clear previous errors
    document.querySelectorAll(".error").forEach(error => {
        error.textContent = "";
    });

    document.querySelectorAll(".form-group input, .form-group textarea")
        .forEach(field => {
            field.classList.remove("invalid");
        });

    successMessage.textContent = "";

    // Function to show errors
    function showError(field, message) {
        const error = field.parentElement.querySelector(".error");

        error.textContent = message;
        field.classList.add("invalid");

        isValid = false;
    }

    // Full Name validation
    if (fullName.value.trim().length < 2) {
        showError(fullName, "Please enter your full name.");
    }

    // Email validation
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailPattern.test(email.value.trim())) {
        showError(email, "Please enter a valid email address.");
    }

    // Phone validation
    const phoneDigits = phone.value.replace(/\D/g, "");

    if (phoneDigits.length < 10 || phoneDigits.length > 15) {
        showError(phone, "Please enter a valid phone number.");
    }

    // Subject validation
    if (subject.value.trim() === "") {
        showError(subject, "Please enter a subject.");
    }

    // Message validation
    if (message.value.trim().length < 10) {
        showError(message, "Message must contain at least 10 characters.");
    }

    // Successful validation
    if (isValid) {
        successMessage.textContent =
            "Thank you! Your message has been submitted successfully.";

        successMessage.style.color = "green";

        form.reset();
    }
});

